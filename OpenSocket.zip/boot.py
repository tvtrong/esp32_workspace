# Posty Project: boot.py
# Copyright (c) 2019 Clayton Darwin claytondarwin@gmail.com

# notify
print('RUN: boot.py')


